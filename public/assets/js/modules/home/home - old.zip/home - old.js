$('#company_id').on('change',function(e){
    e.preventDefault()
    if($(this).val() != null && $(this).val() != ''){
        $('#store_id').html('').sel2dma();
        $('#store_id').prop('disabled', false);
        $('#store_id').focus()
        $.ajax({
            url : baseUrl +  'master_data/m_store/getStore',
            type: 'POST',
            data: {'company_id' : $(this).val()},
            datatype: 'json',
            success: function(data){
                $('#store_id').html(data);
            },
            error: function(){
                alert("can't get store");  
            }
        });
    } else {    
        $('#store_id').html('').sel2dma();
        $('#store_id').prop('disabled', true);        
    }
});

var companyId = ($("#company_id").val() === '' || $("#company_id").val() === null ? companyIduser : $("#company_id").val());
var storeId =  $("#store_id").val();
var title_tahun = '';
var title_bulan = '';
if (typeof(document.getElementById("periode")) !== 'undefined') {
    title_tahun = $("#periode").val().substr(3,4);
    title_bulan = getsortbulan(Number($("#periode").val().substr(0,2))) + ' - ' + $("#periode").val().substr(3,4);    
}    

// loaddata();
$("#btn-submit").on('click', function (e) {
    e.preventDefault();
    if($('#company_id').val() === null || $('#company_id').val() === ''){
        bksfn.errMsg('Cabang Belum Dipilih!');
    } else {
        companyId = $("#company_id").val();
        storeId = $("#store_id").val();
        title_tahun = $('#periode').val().substr(3,4);
        title_bulan = getsortbulan(Number($("#periode").val().substr(0,2))) + ' - ' + $("#periode").val().substr(3,4);
        loaddata();
    }
});

function loaddata(){
    gettrxbymonth_piechart();
    gettrxbyyear_piechart();
    gettrxbymonth_linechart();
    gettrxbymonth_barchart();
    gettrxbyytd_pivot();
}

function gettrxbymonth_piechart(){
    if( typeof(companyId) !== 'undefined') {
        if(companyId !== null && companyId !== '') {
            $("#home-donut-1").empty();
            $("#ftitle_home-donut-1").html(title_bulan);
            $.ajax({
                url: baseUrl + 'home/home/gettrxbymonth_piechart',
                type: 'POST',
                data: {'company_id' : companyId,
                       'store_id' : storeId,
                       'periode' : $('#periode').val()
                    },
                dataType: 'json',
                success: function (data) {
                    if (data !== '[]' && data.length > 0){                                                
                        var d = (data)[0];
                        var xbuy_equivalent = (d.buy_equivalent === null ? 0 : Number(d.buy_equivalent));
                        var xsales_equivalent = (d.sales_equivalent === null ? 0 : Number(d.sales_equivalent));
                        if(xbuy_equivalent > 0 || xsales_equivalent > 0){
                            Morris.Donut({
                                element: 'home-donut-1',
                                data: [
                                    {label: "Buy", value: xbuy_equivalent},
                                    {label: "Sales", value: xsales_equivalent}
                                ],
                                colors: ['#0000FF', '#FF0000', '#FEA223'],
                                resize: true
                            });
                        }                                                
                    }
                },
                error: function(xhr){
                    alertify.error(xhr.responseText);
                }
            });
        }
    }        
}

function gettrxbyyear_piechart(){
    if( typeof(companyId) !== 'undefined') {
        if(companyId !== null && companyId !== '') {
            $("#home-donut-2").empty();
            $("#ftitle_home-donut-2").html(title_tahun);
            $.ajax({
                url: baseUrl + 'home/home/gettrxbyyear_piechart',
                type: 'POST',
                data: {'company_id' : companyId,
                       'store_id' : storeId,
                       'periode' : $('#periode').val()
                    },
                dataType: 'json',
                success: function (data) {
                    if (data !== '[]' && data.length > 0){                                                
                        var d = (data)[0];
                        var xbuy_equivalent = (d.buy_equivalent === null ? 0 : Number(d.buy_equivalent));
                        var xsales_equivalent = (d.sales_equivalent === null ? 0 : Number(d.sales_equivalent));
                        if(xbuy_equivalent > 0 || xsales_equivalent > 0){
                            Morris.Donut({
                                element: 'home-donut-2',
                                data: [
                                    {label: "Buy", value: xbuy_equivalent},
                                    {label: "Sales", value: xsales_equivalent}
                                ],
                                colors: ['#0000FF', '#FF0000', '#FEA223'],
                                resize: true
                            });
                        }                            
                    }
                },
                error: function(xhr){
                    alertify.error(xhr.responseText);
                }
            });
        }
    }        
}

function gettrxbymonth_linechart(){
    if( typeof(companyId) !== 'undefined') {
        if(companyId !== null && companyId !== '') {
            var datasource1 = [];
            $("#home-line-1").empty();
            $("#ftitle_home-line-1").html(title_tahun);
            $.ajax({
                url: baseUrl + 'home/home/gettrxbymonth',
                type: 'POST',
                data: {'company_id' : companyId,
                       'store_id' : storeId,
                       'periode' : $('#periode').val()
                    },
                dataType: 'json',
                success: function (data) {
                    if (data !== '[]' && data.length > 0){
                        var d = (data)[0];
                        $.each(data, function (i, d) {      
                            var xbuy_equivalent = (d.buy_equivalent === null ? 0 : Number(d.buy_equivalent));
                            var xsales_equivalent = (d.sales_equivalent === null ? 0 : Number(d.sales_equivalent));
                            if(xbuy_equivalent > 0 || xsales_equivalent > 0){                      
                                var obj = {};                   
                                obj["tr_month"] = getsortbulan(Number(d.tr_month));
                                obj["buy"] = xbuy_equivalent;
                                obj["sales"] = xsales_equivalent;
                                datasource1.push(obj);
                            }    
                        });
                        if(datasource1.length > 0){
                            Morris.Line({
                                element: 'home-line-1',
                                data : datasource1,
                                xkey: 'tr_month',
                                ykeys: ['buy','sales'],
                                labels: ['Buy','Sales'],
                                resize: true,
                                hideHover: true,
                                // xLabels: 'month',
                                gridTextSize: '10px',
                                lineColors: ['#0000FF', '#FF0000'],
                                gridLineColor: '#E5E5E5'
                              });                            
                        }                        
                    }
                },
                error: function(xhr){
                    alertify.error(xhr.responseText);
                }
            });
        }
    }        
}

function gettrxbymonth_barchart(){
    if( typeof(companyId) !== 'undefined') {
        if(companyId !== null && companyId !== '') {
            var datasource2 = [];
            $("#home-bar-1").empty();
            $("#ftitle_home-bar-1").html(title_tahun);
            $.ajax({
                url: baseUrl + 'home/home/gettrxbymonth',
                type: 'POST',
                data: {'company_id' : companyId,
                       'store_id' : storeId,
                       'periode' : $('#periode').val()
                    },
                dataType: 'json',
                success: function (data) {
                    if (data !== '[]' && data.length > 0){
                        var d = (data)[0];
                        $.each(data, function (i, d) {
                            var xbuy_equivalent = (d.buy_equivalent === null ? 0 : Number(d.buy_equivalent));
                            var xsales_equivalent = (d.sales_equivalent === null ? 0 : Number(d.sales_equivalent));
                            if(xbuy_equivalent > 0 || xsales_equivalent > 0){
                                var obj = {};
                                obj["tr_month"] = getsortbulan(Number(d.tr_month));
                                obj["buy"] = xbuy_equivalent;
                                obj["sales"] = xsales_equivalent;
                                datasource2.push(obj);
                            }    
                        });
                        if(datasource2.length > 0){
                            Morris.Bar({
                                element: 'home-bar-1',                                        
                                data : datasource2,
                                xkey: 'tr_month',
                                ykeys: ['buy', 'sales'],
                                labels: ['Buy', 'Sales'],
                                barColors: ['#0000FF', '#FF0000'],
                                gridTextSize: '10px',
                                hideHover: true,
                                resize: true,
                                gridLineColor: '#E5E5E5'
                            });
                        }                        
                    }
                },
                error: function(xhr){
                    alertify.error(xhr.responseText);
                }
            });
        }
    }        
}

function gettrxbyytd_pivot(){
    $('#table-pivot-ytd tbody').empty();
    $("#table-pivot-ytd").tableHeadFixer();
    $("#ftitle_home-table-pivot-ytd").html(title_tahun);
    $.ajax({
        url: baseUrl + 'home/home/gettrxbyytd_pivot',
        type: 'POST',
        data: {'company_id' : companyId,
                       'store_id' : storeId,
                       'periode' : $('#periode').val()
                    },
        dataType: 'json',
        success: function (data) {
            if (data !== '[]' && data.length > 0){
                $.each(data, function (i, d) {                 
                    var rows =`<tr>
                                <td width="10%" style="vertical-align: middle;color:black">
                                    ` + d.valas_code +`                       
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy1) == 0 ? '-' : toRp(d.buy1)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales1) == 0 ? '-' : toRp(d.sales1)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy2) == 0 ? '-' : toRp(d.buy2)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales2) == 0 ? '-' : toRp(d.sales2)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy3) == 0 ? '-' : toRp(d.buy3)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales3) == 0 ? '-' : toRp(d.sales3)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy4) == 0 ? '-' : toRp(d.buy4)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales4) == 0 ? '-' : toRp(d.sales4)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy5) == 0 ? '-' : toRp(d.buy5)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales5) == 0 ? '-' : toRp(d.sales5)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy6) == 0 ? '-' : toRp(d.buy6)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales6) == 0 ? '-' : toRp(d.sales6)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy7) == 0 ? '-' : toRp(d.buy7)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales7) == 0 ? '-' : toRp(d.sales7)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy8) == 0 ? '-' : toRp(d.buy8)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales8) == 0 ? '-' : toRp(d.sales8)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy9) == 0 ? '-' : toRp(d.buy9)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales9) == 0 ? '-' : toRp(d.sales9)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy10) == 0 ? '-' : toRp(d.buy10)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales10) == 0 ? '-' : toRp(d.sales10)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy11) == 0 ? '-' : toRp(d.buy11)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales11) == 0 ? '-' : toRp(d.sales11)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.buy12) == 0 ? '-' : toRp(d.buy12)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.sales12) == 0 ? '-' : toRp(d.sales12)) + `
                                </td>

                                <td width="2%" style='text-align:center;color:blue;'>
                                    ` + (Number(d.total_buy) == 0 ? '-' : toRp(d.total_buy)) + `
                                </td>
                                <td width="2%" style='text-align:center;color:red;'>
                                    ` + (Number(d.total_sales) == 0 ? '-' : toRp(d.total_sales)) + `
                                </td>
                            </tr>`
                    $('#table-pivot-ytd tbody').append(rows);
                });
            }
        },
        error: function(xhr){
            alertify.error(xhr.responseText);
        }
    });

}

function getfullbulan(bln){
    var lbulan = '';
    switch(bln) {
        case 1:
            lbulan = 'January';
            break;
        case 2:
            lbulan = 'February';
            break;
        case 3:
            lbulan = 'March';
            break;  
        case 4:
            lbulan = 'April';
            break;
        case 5:
            lbulan = 'Mei';
            break;
        case 6:
            lbulan = 'Juni';
            break;             
        case 7:
            lbulan = 'July';
            break;
        case 8:
            lbulan = 'August';
            break;
        case 9:
            lbulan = 'September';
            break;  
        case 10:
            lbulan = 'October';
            break;
        case 11:
            lbulan = 'November';
            break;
        case 12:
            lbulan = 'December';
            break;
    }
    return lbulan;
}

function getsortbulan(bln){
    var lbulan = '';
    switch(bln) {
        case 1:
            lbulan = 'Jan';
            break;
        case 2:
            lbulan = 'Feb';
            break;
        case 3:
            lbulan = 'Mar';
            break;  
        case 4:
            lbulan = 'Apr';
            break;
        case 5:
            lbulan = 'Mei';
            break;
        case 6:
            lbulan = 'Juni';
            break;             
        case 7:
            lbulan = 'Jul';
            break;
        case 8:
            lbulan = 'Ags';
            break;
        case 9:
            lbulan = 'Sep';
            break;  
        case 10:
            lbulan = 'Oct';
            break;
        case 11:
            lbulan = 'Nov';
            break;
        case 12:
            lbulan = 'Dec';
            break;
    }
    return lbulan;
}

function toRp(angka) {
    var rev = parseInt(angka, 10).toString().split('').reverse().join('');
    var rev2 = '';
    for (var i = 0; i < rev.length; i++) {
        rev2 += rev[i];
        if ((i + 1) % 3 === 0 && i !== (rev.length - 1)) {
            rev2 += '.';
        }
    }
    return rev2.split('').reverse().join('');
}