<?php

class Home extends Bks_Controller {

    function __construct() {
        // $config = array('modules' => 'home', 'jsfiles' => array('c3/d3.v3.min', 'c3/c3'), 'cssfiles' => array('c3/c3.min'));
        $config = array('modules' => 'home', 'jsfiles' => array('home'));
        parent::__construct($config);
        $this->auth = $this->session->userdata('auth');
        $this->userid = $this->auth['id'];
    }
    
    Public function index() {
        $this->libauth->check(__METHOD__);
        $user_id =  $this->auth['id'];
        $data['user_information'] = $this->get_user_information($user_id);
        $this->template->title('Dashboard');
        $this->template->set('tsmall', 'Home');
        $this->template->set('icon', 'fa fa-home');
        $this->template->build('home/home_v',$data);
    }
    
    protected function get_user_information($user_id)
    {
        $result = $this->db->get_where('v_auth_users', array('id' => $user_id));
        if($result->num_rows() > 0){
            return $result->result();
        }
        else{
            exit("User not found");
        }
    }
    
    function gettrxbymonth_piechart() {
        checkIfNotAjax();
        $this->libauth->check(__METHOD__);
        $postData = $this->input->post();
        $company_id = $postData['company_id'];
        $store_id = $postData['store_id'];

        $tahun = date('Y');
        $bulan = date('m');
        if(isset($postData['periode'])){
            $tahun = intval(SUBSTR($postData['periode'],3,4));
            $bulan = intval(SUBSTR($postData['periode'],0,2));
        }

        $query = $this->db->query("SELECT SUM( buy_equivalent ) AS buy_equivalent,
                                        SUM( sales_equivalent ) AS sales_equivalent
                                    FROM v_summary_by_month
                                    WHERE company_id = $company_id
                                    AND tr_year = $tahun
                                    AND tr_month = $bulan")->result();        
        
        if($store_id !== null && $store_id !== ''){
            $query = $this->db->query("SELECT SUM( buy_equivalent ) AS buy_equivalent,
                                        SUM( sales_equivalent ) AS sales_equivalent
                                    FROM v_summary_by_month
                                    WHERE company_id = $company_id
                                    AND store_id = $store_id
                                    AND tr_year = $tahun
                                    AND tr_month = $bulan")->result();
        }        
        echo json_encode($query, true);
    }

    function gettrxbyyear_piechart() {
        checkIfNotAjax();
        $this->libauth->check(__METHOD__);
        $postData = $this->input->post();
        $company_id = $postData['company_id'];
        $store_id = $postData['store_id'];

        $tahun = date('Y');
        $bulan = date('m');
        if(isset($postData['periode'])){
            $tahun = intval(SUBSTR($postData['periode'],3,4));
            $bulan = intval(SUBSTR($postData['periode'],0,2));
        }

        $query = $this->db->query("SELECT SUM( buy_equivalent ) AS buy_equivalent,
                                        SUM( sales_equivalent ) AS sales_equivalent
                                    FROM v_summary_by_month
                                    WHERE company_id = $company_id
                                    AND tr_year = $tahun")->result();        
        
        if($store_id !== null && $store_id !== ''){
            $query = $this->db->query("SELECT SUM( buy_equivalent ) AS buy_equivalent,
                                        SUM( sales_equivalent ) AS sales_equivalent
                                    FROM v_summary_by_month
                                    WHERE company_id = $company_id
                                    AND store_id = $store_id
                                    AND tr_year = $tahun")->result();
        }
        echo json_encode($query, true);
    }
    
    function gettrxbymonth() {
        checkIfNotAjax();
        $this->libauth->check(__METHOD__);
        $postData = $this->input->post();
        $company_id = $postData['company_id'];
        $store_id = $postData['store_id'];
        
        $tahun = date('Y');
        $bulan = date('m');
        if(isset($postData['periode'])){
            $tahun = intval(SUBSTR($postData['periode'],3,4));
            $bulan = intval(SUBSTR($postData['periode'],0,2));
        }

        $query = $this->db->query("SELECT tr_month,
                                        SUM( buy_equivalent ) AS buy_equivalent,
                                        SUM( sales_equivalent ) AS sales_equivalent
                                    FROM v_summary_by_month
                                    WHERE company_id = $company_id
                                    AND tr_year = $tahun
                                    GROUP BY tr_month
                                    ORDER BY tr_month ASC")->result();

        if($store_id !== null && $store_id !== ''){
            $query = $this->db->query("SELECT tr_month,
                                        SUM( buy_equivalent ) AS buy_equivalent,
                                        SUM( sales_equivalent ) AS sales_equivalent
                                    FROM v_summary_by_month
                                    WHERE company_id = $company_id
                                    AND store_id = $store_id
                                    AND tr_year = $tahun
                                    GROUP BY tr_month
                                    ORDER BY tr_month ASC")->result();
        }
        echo json_encode($query, true);
    }

    function gettrxbyytd_pivot() {
        checkIfNotAjax();
        $this->libauth->check(__METHOD__);
        $postData = $this->input->post();

        $company_id = $postData['company_id'];
        $store_id = $postData['store_id'];

        $tahun = date('Y');
        $bulan = date('m');
        if(isset($postData['periode'])){
            $tahun = intval(SUBSTR($postData['periode'],3,4));
            $bulan = intval(SUBSTR($postData['periode'],0,2));
        }

        $query = $this->db->query("SELECT * FROM v_summary_by_amount_pivot_ytd
                                   WHERE company_id = $company_id
                                    AND tr_year = $tahun
                                    ORDER BY valas_id ASC")->result();

        if($store_id !== null && $store_id !== ''){
            $query = $this->db->query("SELECT * FROM v_summary_by_amount_pivot_ytd
                                        WHERE company_id = $company_id
                                        AND store_id = $store_id
                                        AND tr_year = $tahun
                                        ORDER BY valas_id ASC")->result();
        }

        echo json_encode($query, true);
    }
        
}
